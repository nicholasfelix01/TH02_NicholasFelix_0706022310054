﻿namespace TH0202_NF
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbl_0 = new Label();
            lbl_1 = new Label();
            lbl_2 = new Label();
            lbl_3 = new Label();
            lbl_4 = new Label();
            btn_A = new Button();
            btn_G = new Button();
            btn_H = new Button();
            btn_J = new Button();
            btn_K = new Button();
            btn_F = new Button();
            btn_D = new Button();
            btn_S = new Button();
            btn_L = new Button();
            btn_O = new Button();
            btn_W = new Button();
            btn_E = new Button();
            btn_R = new Button();
            btn_I = new Button();
            btn_U = new Button();
            btn_Y = new Button();
            btn_T = new Button();
            btn_Q = new Button();
            btn_P = new Button();
            btn_M = new Button();
            btn_Z = new Button();
            btn_X = new Button();
            btn_N = new Button();
            btn_B = new Button();
            btn_V = new Button();
            btn_C = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // lbl_0
            // 
            lbl_0.AutoSize = true;
            lbl_0.Font = new Font("Segoe Print", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_0.Location = new Point(248, 9);
            lbl_0.Name = "lbl_0";
            lbl_0.Size = new Size(70, 105);
            lbl_0.TabIndex = 0;
            lbl_0.Text = "_";
            // 
            // lbl_1
            // 
            lbl_1.AutoSize = true;
            lbl_1.Font = new Font("Segoe Print", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_1.Location = new Point(306, 9);
            lbl_1.Name = "lbl_1";
            lbl_1.Size = new Size(70, 105);
            lbl_1.TabIndex = 1;
            lbl_1.Text = "_";
            // 
            // lbl_2
            // 
            lbl_2.AutoSize = true;
            lbl_2.Font = new Font("Segoe Print", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_2.Location = new Point(365, 9);
            lbl_2.Name = "lbl_2";
            lbl_2.Size = new Size(70, 105);
            lbl_2.TabIndex = 2;
            lbl_2.Text = "_";
            // 
            // lbl_3
            // 
            lbl_3.AutoSize = true;
            lbl_3.Font = new Font("Segoe Print", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_3.Location = new Point(421, 9);
            lbl_3.Name = "lbl_3";
            lbl_3.Size = new Size(70, 105);
            lbl_3.TabIndex = 3;
            lbl_3.Text = "_";
            // 
            // lbl_4
            // 
            lbl_4.AutoSize = true;
            lbl_4.Font = new Font("Segoe Print", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbl_4.Location = new Point(479, 9);
            lbl_4.Name = "lbl_4";
            lbl_4.Size = new Size(70, 105);
            lbl_4.TabIndex = 4;
            lbl_4.Text = "_";
            // 
            // btn_A
            // 
            btn_A.Location = new Point(147, 231);
            btn_A.Name = "btn_A";
            btn_A.Size = new Size(48, 45);
            btn_A.TabIndex = 5;
            btn_A.Text = "A";
            btn_A.UseVisualStyleBackColor = true;
            btn_A.Click += btn_A_Click;
            // 
            // btn_G
            // 
            btn_G.Location = new Point(363, 231);
            btn_G.Name = "btn_G";
            btn_G.Size = new Size(48, 45);
            btn_G.TabIndex = 6;
            btn_G.Text = "G";
            btn_G.UseVisualStyleBackColor = true;
            btn_G.Click += btn_G_Click;
            // 
            // btn_H
            // 
            btn_H.Location = new Point(417, 231);
            btn_H.Name = "btn_H";
            btn_H.Size = new Size(48, 45);
            btn_H.TabIndex = 7;
            btn_H.Text = "H";
            btn_H.UseVisualStyleBackColor = true;
            btn_H.Click += btn_H_Click;
            // 
            // btn_J
            // 
            btn_J.Location = new Point(471, 231);
            btn_J.Name = "btn_J";
            btn_J.Size = new Size(48, 45);
            btn_J.TabIndex = 8;
            btn_J.Text = "J";
            btn_J.UseVisualStyleBackColor = true;
            btn_J.Click += btn_J_Click;
            // 
            // btn_K
            // 
            btn_K.Location = new Point(525, 231);
            btn_K.Name = "btn_K";
            btn_K.Size = new Size(48, 45);
            btn_K.TabIndex = 9;
            btn_K.Text = "K";
            btn_K.UseVisualStyleBackColor = true;
            btn_K.Click += btn_K_Click;
            // 
            // btn_F
            // 
            btn_F.Location = new Point(309, 231);
            btn_F.Name = "btn_F";
            btn_F.Size = new Size(48, 45);
            btn_F.TabIndex = 10;
            btn_F.Text = "F";
            btn_F.UseVisualStyleBackColor = true;
            btn_F.Click += btn_F_Click;
            // 
            // btn_D
            // 
            btn_D.Location = new Point(255, 231);
            btn_D.Name = "btn_D";
            btn_D.Size = new Size(48, 45);
            btn_D.TabIndex = 11;
            btn_D.Text = "D";
            btn_D.UseVisualStyleBackColor = true;
            btn_D.Click += btn_D_Click;
            // 
            // btn_S
            // 
            btn_S.Location = new Point(201, 231);
            btn_S.Name = "btn_S";
            btn_S.Size = new Size(48, 45);
            btn_S.TabIndex = 12;
            btn_S.Text = "S";
            btn_S.UseVisualStyleBackColor = true;
            btn_S.Click += btn_S_Click;
            // 
            // btn_L
            // 
            btn_L.Location = new Point(579, 231);
            btn_L.Name = "btn_L";
            btn_L.Size = new Size(48, 45);
            btn_L.TabIndex = 13;
            btn_L.Text = "L";
            btn_L.UseVisualStyleBackColor = true;
            btn_L.Click += btn_L_Click;
            // 
            // btn_O
            // 
            btn_O.Location = new Point(555, 180);
            btn_O.Name = "btn_O";
            btn_O.Size = new Size(48, 45);
            btn_O.TabIndex = 22;
            btn_O.Text = "O";
            btn_O.UseVisualStyleBackColor = true;
            btn_O.Click += btn_O_Click;
            // 
            // btn_W
            // 
            btn_W.Location = new Point(177, 180);
            btn_W.Name = "btn_W";
            btn_W.Size = new Size(48, 45);
            btn_W.TabIndex = 21;
            btn_W.Text = "W";
            btn_W.UseVisualStyleBackColor = true;
            btn_W.Click += btn_W_Click;
            // 
            // btn_E
            // 
            btn_E.Location = new Point(231, 180);
            btn_E.Name = "btn_E";
            btn_E.Size = new Size(48, 45);
            btn_E.TabIndex = 20;
            btn_E.Text = "E";
            btn_E.UseVisualStyleBackColor = true;
            btn_E.Click += btn_E_Click;
            // 
            // btn_R
            // 
            btn_R.Location = new Point(285, 180);
            btn_R.Name = "btn_R";
            btn_R.Size = new Size(48, 45);
            btn_R.TabIndex = 19;
            btn_R.Text = "R";
            btn_R.UseVisualStyleBackColor = true;
            btn_R.Click += btn_R_Click;
            // 
            // btn_I
            // 
            btn_I.Location = new Point(501, 180);
            btn_I.Name = "btn_I";
            btn_I.Size = new Size(48, 45);
            btn_I.TabIndex = 18;
            btn_I.Text = "I";
            btn_I.UseVisualStyleBackColor = true;
            btn_I.Click += btn_I_Click;
            // 
            // btn_U
            // 
            btn_U.Location = new Point(447, 180);
            btn_U.Name = "btn_U";
            btn_U.Size = new Size(48, 45);
            btn_U.TabIndex = 17;
            btn_U.Text = "U";
            btn_U.UseVisualStyleBackColor = true;
            btn_U.Click += btn_U_Click;
            // 
            // btn_Y
            // 
            btn_Y.Location = new Point(393, 180);
            btn_Y.Name = "btn_Y";
            btn_Y.Size = new Size(48, 45);
            btn_Y.TabIndex = 16;
            btn_Y.Text = "Y";
            btn_Y.UseVisualStyleBackColor = true;
            btn_Y.Click += btn_Y_Click;
            // 
            // btn_T
            // 
            btn_T.Location = new Point(339, 180);
            btn_T.Name = "btn_T";
            btn_T.Size = new Size(48, 45);
            btn_T.TabIndex = 15;
            btn_T.Text = "T";
            btn_T.UseVisualStyleBackColor = true;
            btn_T.Click += btn_T_Click;
            // 
            // btn_Q
            // 
            btn_Q.Location = new Point(123, 180);
            btn_Q.Name = "btn_Q";
            btn_Q.Size = new Size(48, 45);
            btn_Q.TabIndex = 14;
            btn_Q.Text = "Q";
            btn_Q.UseVisualStyleBackColor = true;
            btn_Q.Click += btn_Q_Click;
            // 
            // btn_P
            // 
            btn_P.Location = new Point(609, 180);
            btn_P.Name = "btn_P";
            btn_P.Size = new Size(48, 45);
            btn_P.TabIndex = 23;
            btn_P.Text = "P";
            btn_P.UseVisualStyleBackColor = true;
            btn_P.Click += btn_P_Click;
            // 
            // btn_M
            // 
            btn_M.Location = new Point(490, 282);
            btn_M.Name = "btn_M";
            btn_M.Size = new Size(48, 45);
            btn_M.TabIndex = 32;
            btn_M.Text = "M";
            btn_M.UseVisualStyleBackColor = true;
            btn_M.Click += btn_M_Click;
            // 
            // btn_Z
            // 
            btn_Z.Location = new Point(166, 282);
            btn_Z.Name = "btn_Z";
            btn_Z.Size = new Size(48, 45);
            btn_Z.TabIndex = 30;
            btn_Z.Text = "Z";
            btn_Z.UseVisualStyleBackColor = true;
            btn_Z.Click += btn_Z_Click;
            // 
            // btn_X
            // 
            btn_X.Location = new Point(220, 282);
            btn_X.Name = "btn_X";
            btn_X.Size = new Size(48, 45);
            btn_X.TabIndex = 29;
            btn_X.Text = "X";
            btn_X.UseVisualStyleBackColor = true;
            btn_X.Click += btn_X_Click;
            // 
            // btn_N
            // 
            btn_N.Location = new Point(436, 282);
            btn_N.Name = "btn_N";
            btn_N.Size = new Size(48, 45);
            btn_N.TabIndex = 28;
            btn_N.Text = "N";
            btn_N.UseVisualStyleBackColor = true;
            btn_N.Click += btn_N_Click;
            // 
            // btn_B
            // 
            btn_B.Location = new Point(382, 282);
            btn_B.Name = "btn_B";
            btn_B.Size = new Size(48, 45);
            btn_B.TabIndex = 27;
            btn_B.Text = "B";
            btn_B.UseVisualStyleBackColor = true;
            btn_B.Click += btn_B_Click;
            // 
            // btn_V
            // 
            btn_V.Location = new Point(328, 282);
            btn_V.Name = "btn_V";
            btn_V.Size = new Size(48, 45);
            btn_V.TabIndex = 26;
            btn_V.Text = "V";
            btn_V.UseVisualStyleBackColor = true;
            btn_V.Click += btn_V_Click;
            // 
            // btn_C
            // 
            btn_C.Location = new Point(274, 282);
            btn_C.Name = "btn_C";
            btn_C.Size = new Size(48, 45);
            btn_C.TabIndex = 25;
            btn_C.Text = "C";
            btn_C.UseVisualStyleBackColor = true;
            btn_C.Click += btn_C_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe Print", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(42, 368);
            label1.Name = "label1";
            label1.Size = new Size(87, 40);
            label1.TabIndex = 33;
            label1.Text = "label1";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(btn_M);
            Controls.Add(btn_Z);
            Controls.Add(btn_X);
            Controls.Add(btn_N);
            Controls.Add(btn_B);
            Controls.Add(btn_V);
            Controls.Add(btn_C);
            Controls.Add(btn_P);
            Controls.Add(btn_O);
            Controls.Add(btn_W);
            Controls.Add(btn_E);
            Controls.Add(btn_R);
            Controls.Add(btn_I);
            Controls.Add(btn_U);
            Controls.Add(btn_Y);
            Controls.Add(btn_T);
            Controls.Add(btn_Q);
            Controls.Add(btn_L);
            Controls.Add(btn_S);
            Controls.Add(btn_D);
            Controls.Add(btn_F);
            Controls.Add(btn_K);
            Controls.Add(btn_J);
            Controls.Add(btn_H);
            Controls.Add(btn_G);
            Controls.Add(btn_A);
            Controls.Add(lbl_4);
            Controls.Add(lbl_3);
            Controls.Add(lbl_2);
            Controls.Add(lbl_1);
            Controls.Add(lbl_0);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_0;
        private Label lbl_1;
        private Label lbl_2;
        private Label lbl_3;
        private Label lbl_4;
        private Button btn_A;
        private Button btn_G;
        private Button btn_H;
        private Button btn_J;
        private Button btn_K;
        private Button btn_F;
        private Button btn_D;
        private Button btn_S;
        private Button btn_L;
        private Button btn_O;
        private Button btn_W;
        private Button btn_E;
        private Button btn_R;
        private Button btn_I;
        private Button btn_U;
        private Button btn_Y;
        private Button btn_T;
        private Button btn_Q;
        private Button btn_P;
        private Button btn_M;
        private Button btn_Z;
        private Button btn_X;
        private Button btn_N;
        private Button btn_B;
        private Button btn_V;
        private Button btn_C;
        private Label label1;
    }
}